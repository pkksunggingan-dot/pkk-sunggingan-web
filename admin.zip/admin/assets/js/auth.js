/* ═══════════════════════════════════════════════════════════════
   AUTHENTICATION MODULE
   ═══════════════════════════════════════════════════════════════ */

const Auth = {
  /**
   * Login dengan email + password
   * @returns {Promise<{success: boolean, error?: string, user?: object, admin?: object}>}
   */
  async login(email, password) {
    try {
      const { data, error } = await window.sb.auth.signInWithPassword({
        email: email,
        password: password
      });

      if (error) {
        return { success: false, error: this.translateError(error.message) };
      }

      // Verify user terdaftar di table `admins`
      const { data: adminData, error: adminError } = await window.sb
        .from('admins')
        .select('*')
        .eq('id', data.user.id)
        .single();

      if (adminError || !adminData) {
        // User login-nya sukses tapi bukan admin yang terdaftar
        await window.sb.auth.signOut();
        return { success: false, error: 'Email ini tidak terdaftar sebagai admin.' };
      }

      return { success: true, user: data.user, admin: adminData };
    } catch (err) {
      console.error('Login error:', err);
      return { success: false, error: 'Terjadi kesalahan. Coba lagi.' };
    }
  },

  /**
   * Logout current user
   */
  async logout() {
    await window.sb.auth.signOut();
    window.location.href = '/admin/login.html';
  },

  /**
   * Get current session (kalau ada)
   * @returns {Promise<object|null>}
   */
  async getSession() {
    const { data } = await window.sb.auth.getSession();
    return data.session;
  },

  /**
   * Get current user (kalau login)
   * @returns {Promise<object|null>}
   */
  async getCurrentUser() {
    const session = await this.getSession();
    if (!session) return null;
    return session.user;
  },

  /**
   * Get admin info dari table `admins`
   * @returns {Promise<object|null>}
   */
  async getAdminInfo() {
    const user = await this.getCurrentUser();
    if (!user) return null;

    const { data, error } = await window.sb
      .from('admins')
      .select('*')
      .eq('id', user.id)
      .single();

    if (error) return null;
    return data;
  },

  /**
   * Guard: force redirect ke login kalau belum login.
   * Panggil di awal setiap halaman admin.
   */
  async requireAuth() {
    const session = await this.getSession();
    if (!session) {
      window.location.href = '/admin/login.html';
      return false;
    }

    // Verify masih admin
    const admin = await this.getAdminInfo();
    if (!admin) {
      await this.logout();
      return false;
    }

    return true;
  },

  /**
   * Translate error message dari Supabase ke Bahasa Indonesia
   */
  translateError(msg) {
    const translations = {
      'Invalid login credentials': 'Email atau password salah.',
      'Email not confirmed': 'Email belum dikonfirmasi.',
      'User not found': 'Email tidak ditemukan.'
    };
    return translations[msg] || 'Login gagal: ' + msg;
  }
};

// Expose ke global
window.Auth = Auth;